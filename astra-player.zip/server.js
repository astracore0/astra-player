const express = require('express');
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const https = require('https');

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '15mb' }));

const LOG_FILE = path.join(__dirname, 'app.log');

function logEvent(type, message) {
  const now = new Date();
  const timeStr = now.toISOString().replace('T', ' ').substring(0, 19);
  const logLine = `[${timeStr}] [${type}] ${message}\n`;
  fs.appendFile(LOG_FILE, logLine, () => {});
  console.log(`\x1b[36m[${timeStr}]\x1b[0m \x1b[33m[${type}]\x1b[0m ${message}`);
}

const CONFIG_FILE = path.join(__dirname, 'config.json');
let savedConfig = {};
try {
  if (fs.existsSync(CONFIG_FILE)) {
    savedConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
  }
} catch (e) {}

const STORAGE_SHARED = path.join(os.homedir(), 'storage', 'shared');
const DEFAULT_ROOT = fs.existsSync(path.join(STORAGE_SHARED, 'anime')) 
  ? path.join(STORAGE_SHARED, 'anime') 
  : (fs.existsSync('/sdcard/anime') ? '/sdcard/anime' : STORAGE_SHARED);

let MEDIA_ROOT = (savedConfig.mediaRoot && fs.existsSync(savedConfig.mediaRoot)) 
  ? savedConfig.mediaRoot 
  : DEFAULT_ROOT;

const SUBTITLES_DIR = path.join(__dirname, 'subtitles');
if (!fs.existsSync(SUBTITLES_DIR)) fs.mkdirSync(SUBTITLES_DIR, { recursive: true });

const HISTORY_FILE = path.join(__dirname, 'history.json');
if (!fs.existsSync(HISTORY_FILE)) fs.writeFileSync(HISTORY_FILE, JSON.stringify({}), 'utf-8');

app.use(express.static(path.join(__dirname, 'public')));
app.use('/subs_static', express.static(SUBTITLES_DIR));

const JUNK_FOLDERS = ['whatsapp', 'instagram', 'telegram', 'android', 'cache', 'facebook', 'lost.dir', '.thumbnails'];
const VIDEO_EXTS = ['.mp4', '.mkv', '.webm', '.avi', '.mov', '.ts', '.m4v'];

function scanCleanStorage(dirPath, relativeDir = '') {
  let results = {};
  if (!fs.existsSync(dirPath)) return results;
  try {
    const items = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const item of items) {
      if (item.name.startsWith('.')) continue;
      const lower = item.name.toLowerCase();
      if (JUNK_FOLDERS.some(junk => lower.includes(junk))) continue;

      const fullPath = path.join(dirPath, item.name);
      const relPath = path.join(relativeDir, item.name);

      if (item.isDirectory()) {
        const sub = scanCleanStorage(fullPath, relPath);
        Object.assign(results, sub);
      } else if (item.isFile()) {
        const ext = path.extname(item.name).toLowerCase();
        if (VIDEO_EXTS.includes(ext)) {
          const folderKey = relativeDir ? relativeDir.replace(/\\/g, ' / ') : 'Anime Root';
          if (!results[folderKey]) results[folderKey] = [];
          let sizeStr = '0 MB';
          let dateStr = '';
          try {
            const stats = fs.statSync(fullPath);
            sizeStr = (stats.size / (1024 * 1024)).toFixed(1) + ' MB';
            dateStr = stats.mtime.toLocaleDateString();
          } catch(e) {}

          results[folderKey].push({
            name: item.name,
            relPath: relPath.replace(/\\/g, '/'),
            size: sizeStr,
            date: dateStr
          });
        }
      }
    }
  } catch (err) {}
  return results;
}

app.get('/api/library', (req, res) => {
  const lib = scanCleanStorage(MEDIA_ROOT);
  res.json({ root: MEDIA_ROOT, library: lib });
});

app.post('/api/settings/root', (req, res) => {
  const { newPath } = req.body;
  if (!newPath || !fs.existsSync(newPath)) {
    return res.status(400).json({ success: false, message: 'Directory does not exist' });
  }
  try {
    MEDIA_ROOT = newPath;
    fs.writeFileSync(CONFIG_FILE, JSON.stringify({ mediaRoot: newPath }, null, 2), 'utf-8');
    res.json({ success: true, root: MEDIA_ROOT, library: scanCleanStorage(MEDIA_ROOT) });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to save config' });
  }
});

app.get('/api/system/status', (req, res) => {
  const mem = process.memoryUsage();
  res.json({
    uptime: Math.floor(process.uptime()),
    ramUsedMB: (mem.rss / (1024 * 1024)).toFixed(1),
    root: MEDIA_ROOT,
    nodeVer: process.version
  });
});

app.post('/api/verify-link', (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).json({ valid: false, message: 'URL missing' });
  if (url.match(/\.(mp4|mkv|webm|m3u8|mov)($|\?)/i)) {
    return res.json({ valid: true, type: 'direct', streamUrl: url });
  }
  res.json({ valid: true, type: 'embed', streamUrl: url });
});

app.get('/api/proxy/stream', (req, res) => {
  const targetUrl = req.query.url;
  if (!targetUrl) return res.status(400).send('URL missing');
  try {
    const parsed = new URL(targetUrl);
    const client = parsed.protocol === 'https:' ? https : http;
    const headers = {};
    if (req.headers.range) headers['Range'] = req.headers.range;

    const proxyReq = client.get(targetUrl, { headers }, (proxyRes) => {
      res.writeHead(proxyRes.statusCode, proxyRes.headers);
      proxyRes.pipe(res);
    });
    proxyReq.on('error', () => res.status(502).end());
  } catch (err) {
    res.status(400).send('Invalid URL');
  }
});

function srtToVtt(srtText) {
  return "WEBVTT\n\n" + srtText
    .replace(/\{\\([ibu])\}/g, '</$1>')
    .replace(/\\([ibu])/g, '<$1>')
    .replace(/(\d\d:\d\d:\d\d),(\d\d\d)/g, '$1.$2');
}

app.get('/api/subs/local', (req, res) => {
  try {
    const files = fs.readdirSync(SUBTITLES_DIR).filter(f => f.endsWith('.vtt') || f.endsWith('.srt'));
    const list = files.map(name => {
      const full = path.join(SUBTITLES_DIR, name);
      const st = fs.statSync(full);
      return {
        name,
        size: (st.size / 1024).toFixed(1) + ' KB',
        date: st.mtime.toLocaleDateString()
      };
    });
    res.json(list);
  } catch (e) { res.json([]); }
});

app.post('/api/subs/upload', (req, res) => {
  const { name, content } = req.body;
  if (!name || !content) return res.status(400).send('Missing payload');
  try {
    let cleanName = name.replace(/\.[^/.]+$/, '') + '.vtt';
    let vttText = content;
    if (name.endsWith('.srt')) {
      vttText = srtToVtt(content);
    }
    fs.writeFileSync(path.join(SUBTITLES_DIR, cleanName), vttText, 'utf-8');
    res.json({ status: 'ok', filename: cleanName });
  } catch (err) {
    res.status(500).send('Save failed');
  }
});

app.post('/api/subs/delete', (req, res) => {
  const { filename } = req.body;
  if (!filename) return res.status(400).send('Filename missing');
  try {
    const target = path.join(SUBTITLES_DIR, filename);
    if (fs.existsSync(target)) fs.unlinkSync(target);
    res.json({ status: 'deleted' });
  } catch (e) {
    res.status(500).send('Delete failed');
  }
});

app.get('/api/subs/search', async (req, res) => {
  const q = req.query.q;
  const provider = req.query.provider || 'animetosho';
  if (!q) return res.json([]);

  const cleanQuery = q.replace(/\.[^/.]+$/, '').replace(/\[.*?\]/g, '').trim();

  if (provider === 'opensubtitles') {
    try {
      const osUrl = `https://api.opensubtitles.com/api/v1/subtitles?query=${encodeURIComponent(cleanQuery)}&languages=en`;
      const osRes = await fetch(osUrl, {
        headers: { 'User-Agent': 'AstraPlayer v2.0' }
      });
      if (osRes.ok) {
        const osData = await osRes.json();
        const subs = (osData.data || []).slice(0, 15).map(item => {
          const fileInfo = (item.attributes.files && item.attributes.files[0]) || {};
          return {
            title: `${item.attributes.feature_details?.movie_name || cleanQuery} (${item.attributes.language || 'EN'})`,
            downloadUrl: `https://dl.opensubtitles.org/en/download/sub/${fileInfo.file_id || item.id}`,
            filename: `${cleanQuery}-${item.id}.srt`,
            size: 'Standard SRT',
            provider: 'OpenSubtitles'
          };
        });
        if (subs.length > 0) return res.json(subs);
      }
    } catch (e) {}
  }

  try {
    const fetchRes = await fetch(`https://animetosho.org/search/json?q=${encodeURIComponent(cleanQuery)}`);
    if (fetchRes.ok) {
      const data = await fetchRes.json();
      const subs = [];
      (data || []).slice(0, 15).forEach(item => {
        if (item.attachments) {
          item.attachments.forEach(att => {
            if (att.name.endsWith('.ass') || att.name.endsWith('.srt') || att.name.endsWith('.vtt')) {
              let szStr = 'Direct';
              if (att.size) szStr = (att.size / 1024).toFixed(1) + ' KB';
              else if (item.total_size) szStr = (item.total_size / 1024).toFixed(1) + ' KB';

              subs.push({
                title: `${item.title} (${att.name})`,
                downloadUrl: att.url,
                filename: att.name,
                size: szStr,
                provider: 'AnimeTosho'
              });
            }
          });
        }
      });
      if (subs.length > 0) return res.json(subs);
    }
  } catch (err) {}
  res.json([]);
});

app.post('/api/subs/save', async (req, res) => {
  const { url, filename } = req.body;
  if (!url || !filename) return res.status(400).send('Missing params');
  try {
    const fetchRes = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    let text = await fetchRes.text();
    const saveName = filename.replace(/\.[^/.]+$/, '') + '.vtt';
    if (!filename.endsWith('.vtt')) text = srtToVtt(text);
    fs.writeFileSync(path.join(SUBTITLES_DIR, saveName), text, 'utf-8');
    res.json({ status: 'ok', filename: saveName });
  } catch (err) {
    res.status(500).send('Download error');
  }
});

app.get('/api/history', (req, res) => {
  try { res.json(JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf-8'))); } catch (e) { res.json({}); }
});

app.post('/api/history', (req, res) => {
  const { relPath, name, time, dur } = req.body;
  if (!name) return res.status(400).send('Missing payload');
  try {
    let history = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf-8'));
    const key = relPath || name;
    const percent = dur ? Math.min(100, Math.floor((time / dur) * 100)) : 0;
    history[key] = {
      name,
      time: Math.floor(time),
      dur: Math.floor(dur),
      percent,
      updated: Date.now()
    };
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2), 'utf-8');
    res.json({ status: 'saved' });
  } catch (err) { res.status(500).send('Save failed'); }
});

app.post('/api/history/delete', (req, res) => {
  const { key } = req.body;
  try {
    let history = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf-8'));
    delete history[key];
    fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2), 'utf-8');
    res.json({ status: 'deleted' });
  } catch (e) { res.status(500).send('Delete failed'); }
});

app.post('/api/history/clear', (req, res) => {
  fs.writeFileSync(HISTORY_FILE, JSON.stringify({}), 'utf-8');
  res.json({ status: 'cleared' });
});

app.get('/stream', (req, res) => {
  const videoRel = req.query.file;
  if (!videoRel) return res.status(400).send('No file requested');

  const filePath = path.join(MEDIA_ROOT, videoRel);
  if (!fs.existsSync(filePath)) {
    return res.status(404).send('Not found');
  }

  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const range = req.headers.range;

  const ext = path.extname(filePath).toLowerCase();
  let contentType = 'video/mp4';
  if (ext === '.mkv' || ext === '.webm') contentType = 'video/webm';

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const CHUNK_SIZE = 1024 * 1024 * 4;
    const end = parts[1] ? parseInt(parts[1], 10) : Math.min(start + CHUNK_SIZE - 1, fileSize - 1);

    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': end - start + 1,
      'Content-Type': contentType,
    });
    fs.createReadStream(filePath, { start, end }).pipe(res);
  } else {
    res.writeHead(200, {
      'Content-Length': fileSize,
      'Content-Type': contentType,
    });
    fs.createReadStream(filePath).pipe(res);
  }
});

app.listen(PORT, '0.0.0.0', () => {
  logEvent('SYSTEM', `Astra Engine running on port ${PORT}`);
});
